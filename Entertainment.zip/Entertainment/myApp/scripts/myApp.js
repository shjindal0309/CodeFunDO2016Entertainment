var app = angular.module("myApp",[]);

app.controller("homeCtrl",['$scope','$http', function($scope,$http){
	$scope.activeTab = 'cricket';
	$scope.matches = [];
	$scope.matchData = {};
	$http.get('http://cricapi.com/api/cricket').success(function(response){
		$scope.matches = response.data;
	});
	$scope.getMatchData = function(id){
		$http.get('http://cricapi.com/api/cricketScore?unique_id='+id).success(function(response){
		$scope.matchData = response;
	});
	}
}]);