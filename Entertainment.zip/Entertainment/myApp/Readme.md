Step 1: Install node on your machine.

Step 2: open a terminal or command prompt

Step 3: change directory to the project root folder (where index.html exist)

Step 4: run "npm install" in the terminal or cmd

Step 5: run "node server" in the terminal or cmd

Step 6: open browser and visit "http://localhost:2000"